from fancytexts.fancytext import fancytext
